"use client";

import { useState } from "react";
import type { DrawableAnimation, DrawableObject, TextLabel } from "@/models";
import { useProjectStore } from "@/state/useProjectStore";
import { useEditorStore } from "@/state/useEditorStore";
import {
  getActiveBoard,
  getBoardSquads,
  getPlayerTokenLinkKey,
} from "@/utils/board";
import { clone } from "@/utils/clone";
import { createId } from "@/utils/id";
import ColorPalettePicker from "@/components/ColorPalettePicker";

const numberField = (
  value: number,
  onChange: (value: number) => void,
  min?: number,
  max?: number,
  step = 1
) => (
  <input
    type="number"
    className="h-8 w-full rounded-lg border border-[var(--line)] bg-transparent px-2 text-xs text-[var(--ink-0)]"
    value={Number.isFinite(value) ? value : 0}
    min={min}
    max={max}
    step={step}
    onChange={(event) => onChange(Number(event.target.value))}
  />
);

const lineWidthOptions = [
  { label: "1", value: 0.35 },
  { label: "2", value: 0.5 },
  { label: "3", value: 0.65 },
  { label: "4", value: 0.85 },
  { label: "5", value: 1.1 },
];

const drawableAnimationOptions: Array<{
  value: DrawableAnimation;
  label: string;
}> = [
  { value: "none", label: "None" },
  { value: "fadeIn", label: "Fade in" },
  { value: "fadeOut", label: "Fade out" },
  { value: "draw", label: "Draw (Arrow)" },
  { value: "pop", label: "Pop" },
  { value: "pulse", label: "Pulse" },
  { value: "zoom", label: "Zoom" },
  { value: "highlight", label: "Highlight" },
  { value: "lightning", label: "Lightning" },
  { value: "lightPulse", label: "Light Pulse" },
  { value: "shimmer", label: "Shimmer" },
];
const coneFillPalette = [
  "#f06d4f",
  "#f9bf4a",
  "#ffd166",
  "#8bc34a",
  "#2ec4b6",
  "#2f6cf6",
  "#b5179e",
  "#ff7aa2",
];

const getLineWidthOption = (width: number) => {
  let closest = lineWidthOptions[0];
  let best = Math.abs(width - closest.value);
  for (const option of lineWidthOptions) {
    const delta = Math.abs(width - option.value);
    if (delta < best) {
      closest = option;
      best = delta;
    }
  }
  return closest;
};

type PropertiesPanelProps = {
  floating: boolean;
  onToggleFloating: () => void;
};

export default function PropertiesPanel({
  floating,
  onToggleFloating,
}: PropertiesPanelProps) {
  const project = useProjectStore((state) => state.project);
  const updateObject = useProjectStore((state) => state.updateObject);
  const removeObject = useProjectStore((state) => state.removeObject);
  const addObject = useProjectStore((state) => state.addObject);
  const updateSquadPlayer = useProjectStore((state) => state.updateSquadPlayer);
  const updateBoard = useProjectStore((state) => state.updateBoard);
  const pushHistory = useEditorStore((state) => state.pushHistory);
  const selection = useEditorStore((state) => state.selection);
  const selectedLinkId = useEditorStore((state) => state.selectedLinkId);

  const board = getActiveBoard(project);
  const frameIndex = board?.activeFrameIndex ?? 0;
  const activeFrame = board?.frames[frameIndex];
  const objects = board?.frames[frameIndex]?.objects ?? [];
  const canCopyAcrossFrames =
    board?.mode === "DYNAMIC" && (board?.frames.length ?? 0) > 1;
  const selected = objects.filter((item) => selection.includes(item.id));
  const selectedPlayers = selected.filter(
    (item): item is Extract<DrawableObject, { type: "player" }> =>
      item.type === "player"
  );
  const target = selected[0];
  const lockableSelected = selected.filter((item) =>
    [
      "cone",
      "goal",
      "pole",
      "mannequin",
      "circle",
      "polygon",
      "rect",
      "triangle",
      "arrow",
      "text",
    ].includes(
      item.type
    )
  );
  const allLocked =
    lockableSelected.length > 0 &&
    lockableSelected.every((item) => item.locked);
  const selectedLink = activeFrame?.playerLinks?.find(
    (link) => link.id === selectedLinkId
  );
  const memoBoardSquads = getBoardSquads(project ?? null, board ?? null);
  const playerNameById = (() => {
    const map = new Map<string, string>();
    const squads = [memoBoardSquads.home, memoBoardSquads.away].filter(Boolean);
    squads.forEach((squad) => {
      squad?.players.forEach((player) => {
        const label = player.name || player.positionLabel || "";
        map.set(player.id, label);
        if (player.teamMemberId) {
          map.set(player.teamMemberId, label);
        }
      });
    });
    return map;
  })();
  const selectedLinkStyle = selectedLink?.style ?? {
    stroke: "#f9bf4a",
    strokeWidth: 0.65,
    fill: "transparent",
    dash: [],
    opacity: 1,
    outlineStroke: "#111111",
  };
  const squadPlayerById = (() => {
    const map = new Map<
      string,
      typeof memoBoardSquads.all[number]["players"][number]
    >();
    memoBoardSquads.all.forEach((squad) => {
      squad.players.forEach((player) => {
        map.set(player.id, player);
        if (player.teamMemberId) {
          map.set(player.teamMemberId, player);
        }
      });
    });
    return map;
  })();
  const squadIdByPlayerId = (() => {
    const map = new Map<string, string>();
    memoBoardSquads.all.forEach((squad) => {
      squad.players.forEach((player) => {
        map.set(player.id, squad.id);
        if (player.teamMemberId) {
          map.set(player.teamMemberId, squad.id);
        }
      });
    });
    return map;
  })();
  const playerOptions = [
    ...(memoBoardSquads.home?.players
      .filter((player) => player.active !== false)
      .map((player) => ({
        id: player.id,
        label: `Home: ${player.name} (${player.positionLabel})`,
      })) ?? []),
    ...(memoBoardSquads.away?.players
      .filter((player) => player.active !== false)
      .map((player) => ({
        id: player.id,
        label: `Away: ${player.name} (${player.positionLabel})`,
      })) ?? []),
  ];
  const [copyDialogOpen, setCopyDialogOpen] = useState(false);
  const [copyTargetMode, setCopyTargetMode] = useState<"same" | "other">(
    "same"
  );
  const [copyTargetFrameIndex, setCopyTargetFrameIndex] = useState("0");
  const [copyTargetBoardId, setCopyTargetBoardId] = useState("");
  const otherBoards = (project?.boards ?? []).filter(
    (item) => item.id !== board?.id
  );

  if (!board) {
    return null;
  }

  const linkedSquadPlayerIdsOnBoard = new Set(
    board.frames.flatMap((frame) =>
      frame.objects.flatMap((item) =>
        item.type === "player" &&
        item.id !== target?.id &&
        getPlayerTokenLinkKey(item)
          ? [getPlayerTokenLinkKey(item)!]
          : []
      )
    )
  );

  const update = (payload: Partial<DrawableObject>) => {
    if (!target) {
      return;
    }
    pushHistory(clone(objects));
    updateObject(board.id, frameIndex, target.id, payload);
  };

  const toggleLock = (nextLocked: boolean) => {
    if (lockableSelected.length === 0) {
      return;
    }
    pushHistory(clone(objects));
    lockableSelected.forEach((item) => {
      updateObject(board.id, frameIndex, item.id, { locked: nextLocked });
    });
  };

  const handleDelete = () => {
    if (selected.length === 0) {
      return;
    }
    pushHistory(clone(objects));
    selected.forEach((item) =>
      removeObject(board.id, frameIndex, item.id)
    );
  };

  const handleDuplicate = () => {
    if (selected.length === 0) {
      return;
    }
    pushHistory(clone(objects));
    selected.forEach((item) => {
      const duplicate = clone(item);
      duplicate.id = createId();
      duplicate.position = {
        x: duplicate.position.x + 2,
        y: duplicate.position.y + 2,
      };
      addObject(board.id, frameIndex, duplicate);
    });
  };

  const handleDeleteLink = () => {
    if (!board || !selectedLinkId) {
      return;
    }
    const nextLinks = (activeFrame?.playerLinks ?? []).filter(
      (link) => link.id !== selectedLinkId
    );
    useEditorStore.getState().setSelectedLinkId(null);
    const nextFrames = board.frames.map((frame, index) =>
      index === frameIndex ? { ...frame, playerLinks: nextLinks } : frame
    );
    updateBoard(board.id, { frames: nextFrames });
  };
  const updateLinkStyle = (payload: Partial<typeof selectedLinkStyle>) => {
    if (!board || !selectedLink) {
      return;
    }
    const nextLinks = (activeFrame?.playerLinks ?? []).map((link) =>
      link.id === selectedLink.id
        ? { ...link, style: { ...selectedLinkStyle, ...payload } }
        : link
    );
    const nextFrames = board.frames.map((frame, index) =>
      index === frameIndex ? { ...frame, playerLinks: nextLinks } : frame
    );
    updateBoard(board.id, { frames: nextFrames });
  };
  const removeLinkPlayer = (index: number) => {
    if (!board || !selectedLink) {
      return;
    }
    const nextIds = selectedLink.playerIds.filter((_, i) => i !== index);
    if (nextIds.length < 2) {
      const nextLinks = (activeFrame?.playerLinks ?? []).filter(
        (link) => link.id !== selectedLink.id
      );
      useEditorStore.getState().setSelectedLinkId(null);
      const nextFrames = board.frames.map((frame, idx) =>
        idx === frameIndex ? { ...frame, playerLinks: nextLinks } : frame
      );
      updateBoard(board.id, { frames: nextFrames });
      return;
    }
    const nextLinks = (activeFrame?.playerLinks ?? []).map((link) =>
      link.id === selectedLink.id ? { ...link, playerIds: nextIds } : link
    );
    const nextFrames = board.frames.map((frame, idx) =>
      idx === frameIndex ? { ...frame, playerLinks: nextLinks } : frame
    );
    updateBoard(board.id, { frames: nextFrames });
  };
  const getLinkPlayerLabel = (playerId: string) => {
    const playerObject = objects.find(
      (item) => item.id === playerId && item.type === "player"
    );
    if (playerObject && "squadPlayerId" in playerObject) {
      const linkedPlayerKey = getPlayerTokenLinkKey(playerObject);
      const name = linkedPlayerKey ? playerNameById.get(linkedPlayerKey) : "";
      if (name) {
        return name;
      }
    }
    return playerId;
  };

  const copyPlayerPositions = (direction: "prev" | "next") => {
    if (!board || !canCopyAcrossFrames) {
      return;
    }
    const targetIndex = direction === "prev" ? frameIndex - 1 : frameIndex + 1;
    if (targetIndex < 0 || targetIndex >= board.frames.length) {
      return;
    }
    const targetObjects = board.frames[targetIndex]?.objects ?? [];
    pushHistory(clone(targetObjects));
    selected
      .filter((item) => item.type === "player")
      .forEach((player) => {
        const existing = targetObjects.find((item) => item.id === player.id);
        if (existing) {
          updateObject(board.id, targetIndex, player.id, {
            position: player.position,
          });
        } else {
          addObject(board.id, targetIndex, clone(player));
        }
      });
  };

  const copySelectionToFrame = (direction: "prev" | "next") => {
    if (!board || !canCopyAcrossFrames || selected.length === 0) {
      return;
    }
    const targetIndex = direction === "prev" ? frameIndex - 1 : frameIndex + 1;
    if (targetIndex < 0 || targetIndex >= board.frames.length) {
      return;
    }
    const targetObjects = board.frames[targetIndex]?.objects ?? [];
    pushHistory(clone(targetObjects));
    selected.forEach((item) => {
      const existing = targetObjects.find((entry) => entry.id === item.id);
      const { id, ...payload } = clone(item);
      if (existing) {
        updateObject(board.id, targetIndex, item.id, payload);
      } else {
        addObject(board.id, targetIndex, clone(item));
      }
    });
  };
  const copySelectionToAllFrames = () => {
    if (!board || selected.length === 0 || board.frames.length <= 1) {
      return;
    }
    const selectedById = new Map(selected.map((item) => [item.id, clone(item)]));
    const nextFrames = board.frames.map((frame, index) => {
      if (index === frameIndex) {
        return frame;
      }
      const nextObjects = [...(frame.objects ?? [])];
      selectedById.forEach((item, id) => {
        const existingIndex = nextObjects.findIndex((entry) => entry.id === id);
        if (existingIndex >= 0) {
          nextObjects[existingIndex] = clone(item);
        } else {
          nextObjects.push(clone(item));
        }
      });
      return {
        ...frame,
        objects: nextObjects,
      };
    });
    updateBoard(board.id, { frames: nextFrames });
  };
  const removeSelectionFromAllFrames = () => {
    if (!board || selected.length === 0 || board.frames.length <= 1) {
      return;
    }
    const selectedIds = new Set(selected.map((item) => item.id));
    const nextFrames = board.frames.map((frame) => ({
      ...frame,
      objects: (frame.objects ?? []).filter((item) => !selectedIds.has(item.id)),
    }));
    updateBoard(board.id, { frames: nextFrames });
  };
  const copyPlayersToTarget = (targetBoardId: string, targetFrameIndex: number) => {
    if (!project || selectedPlayers.length === 0) {
      return;
    }
    const targetBoard = project.boards.find((item) => item.id === targetBoardId);
    if (!targetBoard) {
      return;
    }
    if (targetFrameIndex < 0 || targetFrameIndex >= targetBoard.frames.length) {
      return;
    }
    const targetObjects = targetBoard.frames[targetFrameIndex]?.objects ?? [];
    pushHistory(clone(targetObjects));
    selectedPlayers.forEach((player) => {
      const existing = targetObjects.find((item) => item.id === player.id);
      const { id, ...payload } = clone(player);
      if (existing) {
        updateObject(targetBoardId, targetFrameIndex, player.id, payload);
      } else {
        addObject(targetBoardId, targetFrameIndex, clone(player));
      }
    });
  };
  const openCopyDialog = () => {
    setCopyTargetMode("same");
    const fallbackFrame = Math.min(frameIndex + 1, board.frames.length - 1);
    setCopyTargetFrameIndex(String(fallbackFrame));
    setCopyTargetBoardId(otherBoards[0]?.id ?? "");
    setCopyDialogOpen(true);
  };
  const handleCopyToTarget = () => {
    if (copyTargetMode === "same") {
      const targetFrameIndex = Number(copyTargetFrameIndex);
      if (Number.isNaN(targetFrameIndex) || targetFrameIndex === frameIndex) {
        return;
      }
      copyPlayersToTarget(board.id, targetFrameIndex);
      setCopyDialogOpen(false);
      return;
    }
    if (!copyTargetBoardId) {
      return;
    }
    copyPlayersToTarget(copyTargetBoardId, 0);
    setCopyDialogOpen(false);
  };

  return (
    <div className="space-y-4 text-xs text-[var(--ink-1)]">
      <div className="flex items-center justify-between">
        <span className="display-font text-sm text-[var(--accent-0)]">
          Properties
        </span>
        <div className="flex gap-2">
          <button
            className="rounded-full border border-[var(--line)] px-3 py-1 hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
            onClick={onToggleFloating}
          >
            {floating ? "Dock" : "Float"}
          </button>
          <button
            className="rounded-full border border-[var(--line)] px-3 py-1 hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
            onClick={handleDuplicate}
            disabled={selected.length === 0}
          >
            Duplicate
          </button>
          <button
            className="rounded-full border border-[var(--line)] px-3 py-1 hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
            onClick={handleDelete}
            disabled={selected.length === 0}
          >
            Delete
          </button>
        </div>
      </div>
      {lockableSelected.length > 0 && (
        <label className="flex items-center justify-between rounded-2xl border border-[var(--line)] px-3 py-2 text-xs">
          <span>Locked</span>
          <input
            type="checkbox"
            checked={allLocked}
            onChange={(event) => toggleLock(event.target.checked)}
            disabled={project?.isShared}
          />
        </label>
      )}

      {selected.length === 0 && !selectedLink ? (
        <p>Select an object to edit its properties.</p>
      ) : (
        <div className="space-y-4">
          {selected.length === 0 && selectedLink && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">
                Link line
              </p>
              <div className="mt-2 space-y-2">
                {selectedLink.playerIds.map((id, index) => (
                  <div
                    key={`${id}-${index}`}
                    className="flex items-center justify-between rounded-xl border border-[var(--line)] bg-[var(--panel-2)]/70 px-3 py-2 text-[11px]"
                  >
                    <span>
                      {index + 1}. {getLinkPlayerLabel(id)}
                    </span>
                    <button
                      className="rounded-full border border-[var(--line)] px-2 py-1 text-[10px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                      onClick={() => removeLinkPlayer(index)}
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <label className="space-y-1">
                  <span className="text-[11px]">Stroke</span>
                  <ColorPalettePicker
                    value={selectedLinkStyle.stroke}
                    allowTransparent
                    onChange={(value) => updateLinkStyle({ stroke: value })}
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Outline</span>
                  <ColorPalettePicker
                    value={selectedLinkStyle.outlineStroke ?? "#111111"}
                    allowTransparent
                    onChange={(value) =>
                      updateLinkStyle({ outlineStroke: value })
                    }
                  />
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Stroke Size</span>
                  <select
                    className="h-8 w-full rounded-lg border border-[var(--line)] bg-transparent px-2 text-xs text-[var(--ink-0)]"
                    value={getLineWidthOption(selectedLinkStyle.strokeWidth).label}
                    onChange={(event) => {
                      const option = lineWidthOptions.find(
                        (item) => item.label === event.target.value
                      );
                      if (option) {
                        updateLinkStyle({ strokeWidth: option.value });
                      }
                    }}
                  >
                    {lineWidthOptions.map((option) => (
                      <option key={option.label} value={option.label}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                  onClick={handleDeleteLink}
                >
                  Delete link
                </button>
              </div>
            </div>
          )}
          <div className="rounded-2xl border border-[var(--line)] p-3">
            <p className="text-[11px] uppercase text-[var(--ink-1)]">Style</p>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {target.type !== "player" && (
                <>
                  {target.type !== "cone" ? (
                    <label className="space-y-1">
                      <span className="text-[11px]">Stroke</span>
                      <ColorPalettePicker
                        value={target.style.stroke}
                        allowTransparent
                        onChange={(value) =>
                          update({
                            style: { ...target.style, stroke: value },
                          })
                        }
                      />
                    </label>
                  ) : null}
                  <label className="space-y-1">
                    <span className="text-[11px]">Fill</span>
                    <ColorPalettePicker
                      value={target.style.fill}
                      allowTransparent
                      colors={target.type === "cone" ? coneFillPalette : undefined}
                      onChange={(value) =>
                        update({
                          style: { ...target.style, fill: value },
                        })
                      }
                    />
                  </label>
                  {target.type !== "cone" ? (
                    <label className="space-y-1">
                      <span className="text-[11px]">
                        {target.type === "arrow" ? "Stroke Size" : "Stroke Width"}
                      </span>
                      {target.type === "arrow" ? (
                        <select
                          className="h-8 w-full rounded-lg border border-[var(--line)] bg-transparent px-2 text-xs text-[var(--ink-0)]"
                          value={getLineWidthOption(target.style.strokeWidth).label}
                          onChange={(event) => {
                            const option = lineWidthOptions.find(
                              (item) => item.label === event.target.value
                            );
                            if (option) {
                              update({
                                style: {
                                  ...target.style,
                                  strokeWidth: option.value,
                                },
                              });
                            }
                          }}
                        >
                          {lineWidthOptions.map((option) => (
                            <option key={option.label} value={option.label}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        numberField(target.style.strokeWidth, (value) =>
                          update({
                            style: { ...target.style, strokeWidth: value },
                          })
                        )
                      )}
                    </label>
                  ) : null}
                  {target.type === "arrow" && (
                    <>
                      <label className="flex items-center gap-2 text-[11px]">
                        <input
                          type="checkbox"
                          checked={Boolean(target.style.outlineStroke)}
                          onChange={(event) =>
                            update({
                              style: {
                                ...target.style,
                                outlineStroke: event.target.checked
                                  ? target.style.outlineStroke ?? "#111111"
                                  : undefined,
                              },
                            })
                          }
                        />
                        Outline
                      </label>
                      <label className="space-y-1">
                        <span className="text-[11px]">Outline</span>
                        <ColorPalettePicker
                          value={target.style.outlineStroke ?? "#111111"}
                          allowTransparent
                          disabled={!target.style.outlineStroke}
                          onChange={(value) =>
                            update({
                              style: {
                                ...target.style,
                                outlineStroke: value,
                              },
                            })
                          }
                        />
                      </label>
                    </>
                  )}
                </>
              )}
              <label className="space-y-1">
                <span className="text-[11px]">Opacity</span>
                {numberField(target.style.opacity, (value) =>
                  update({
                    style: { ...target.style, opacity: value },
                  })
                )}
              </label>
              {target.type !== "cone" ? (
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={target.style.dash.length > 0}
                    onChange={(event) =>
                      update({
                        style: {
                          ...target.style,
                          dash: event.target.checked ? [1, 1] : [],
                        },
                      })
                    }
                  />
                  Dashed
                </label>
              ) : null}
              {board.mode === "DYNAMIC" && (
                <label className="space-y-1">
                  <span className="text-[11px]">Frame effect</span>
                  <select
                    className="h-8 w-full rounded-lg border border-[var(--line)] bg-transparent px-2 text-xs text-[var(--ink-0)]"
                    value={target.animation ?? "none"}
                    onChange={(event) =>
                      update({
                        animation: event.target.value as DrawableAnimation,
                      })
                    }
                  >
                    {drawableAnimationOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </label>
              )}
            </div>
            {target.type === "player" && (
              <p className="mt-2 text-[11px] text-[var(--ink-1)]">
                Player colors are set in Squad.
              </p>
            )}
            {board.mode === "DYNAMIC" && (
              <p className="mt-2 text-[11px] text-[var(--ink-1)]">
                Frame effects animate during playback between frames.
              </p>
            )}
          </div>

          {canCopyAcrossFrames && selected.length > 0 && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">
                Copy to frame
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                  onClick={() => copySelectionToFrame("prev")}
                  disabled={frameIndex === 0}
                >
                  Copy to prev frame
                </button>
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                  onClick={() => copySelectionToFrame("next")}
                  disabled={frameIndex >= board.frames.length - 1}
                >
                  Copy to next frame
                </button>
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                  onClick={copySelectionToAllFrames}
                  disabled={board.frames.length <= 1}
                >
                  Copy to all frames
                </button>
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                  onClick={removeSelectionFromAllFrames}
                  disabled={board.frames.length <= 1}
                >
                  Remove from all frames
                </button>
              </div>
            </div>
          )}
          {selectedPlayers.length > 0 && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">
                Players
              </p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button
                  className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                  onClick={openCopyDialog}
                >
                  Kopiera till...
                </button>
              </div>
              {copyDialogOpen && (
                <div className="mt-3 space-y-2 rounded-xl border border-[var(--line)] bg-[var(--panel-2)]/60 p-2">
                  <label className="flex items-center gap-2 text-[11px]">
                    <input
                      type="radio"
                      name="copy-target-mode"
                      checked={copyTargetMode === "same"}
                      onChange={() => setCopyTargetMode("same")}
                    />
                    Annan frame i samma board
                  </label>
                  {copyTargetMode === "same" && (
                    <select
                      className="h-8 w-full rounded-lg border border-[var(--line)] bg-[var(--panel-2)] px-2 text-xs text-[var(--ink-0)]"
                      value={copyTargetFrameIndex}
                      onChange={(event) =>
                        setCopyTargetFrameIndex(event.target.value)
                      }
                    >
                      {board.frames.map((frame, index) => (
                        <option
                          key={frame.id}
                          value={String(index)}
                          disabled={index === frameIndex}
                          className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                        >
                          {frame.name} {index === frameIndex ? "(current)" : ""}
                        </option>
                      ))}
                    </select>
                  )}
                  <label className="flex items-center gap-2 text-[11px]">
                    <input
                      type="radio"
                      name="copy-target-mode"
                      checked={copyTargetMode === "other"}
                      onChange={() => setCopyTargetMode("other")}
                    />
                    Första frame i annan board
                  </label>
                  {copyTargetMode === "other" && (
                    <select
                      className="h-8 w-full rounded-lg border border-[var(--line)] bg-[var(--panel-2)] px-2 text-xs text-[var(--ink-0)]"
                      value={copyTargetBoardId}
                      onChange={(event) => setCopyTargetBoardId(event.target.value)}
                    >
                      {otherBoards.length === 0 ? (
                        <option
                          value=""
                          className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                        >
                          Inga andra boards
                        </option>
                      ) : (
                        otherBoards.map((item) => (
                          <option
                            key={item.id}
                            value={item.id}
                            className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                          >
                            {item.name}
                          </option>
                        ))
                      )}
                    </select>
                  )}
                  <div className="flex gap-2">
                    <button
                      className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                      onClick={handleCopyToTarget}
                      disabled={
                        (copyTargetMode === "same" &&
                          Number(copyTargetFrameIndex) === frameIndex) ||
                        (copyTargetMode === "other" && !copyTargetBoardId)
                      }
                    >
                      Copy players
                    </button>
                    <button
                      className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                      onClick={() => setCopyDialogOpen(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {(target.type === "cone" ||
            target.type === "goal" ||
            target.type === "pole" ||
            target.type === "mannequin" ||
            target.type === "circle" ||
            target.type === "polygon" ||
            target.type === "rect" ||
            target.type === "triangle") && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">
                Rotation
              </p>
              <div className="mt-2 grid gap-2">
                <label className="space-y-1">
                  <span className="text-[11px]">Degrees</span>
                  {numberField(target.rotation, (value) =>
                    update({ rotation: value })
                  )}
                </label>
              </div>
            </div>
          )}

          {target.type === "player" && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">
                Player
              </p>
              <div className="mt-2 grid gap-2">
                {canCopyAcrossFrames && (
                  <div className="flex flex-wrap gap-2">
                    <button
                      className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                      onClick={() => copyPlayerPositions("prev")}
                      disabled={frameIndex === 0}
                    >
                      Copy pos to prev frame
                    </button>
                    <button
                      className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-2)] hover:text-[var(--accent-2)]"
                      onClick={() => copyPlayerPositions("next")}
                      disabled={frameIndex >= board.frames.length - 1}
                    >
                      Copy pos to next frame
                    </button>
                  </div>
                )}
                <label className="space-y-1">
                  <span className="text-[11px]">Squad Player</span>
                  <select
                    className="h-8 w-full rounded-lg border border-[var(--line)] bg-[var(--panel-2)] px-2 text-xs text-[var(--ink-0)]"
                    value={target.squadPlayerId ?? ""}
                    onChange={(event) => {
                      const nextSquadPlayerId = event.target.value || undefined;
                      const linkedPlayer = nextSquadPlayerId
                        ? squadPlayerById.get(nextSquadPlayerId)
                        : undefined;
                      update({
                        squadPlayerId: nextSquadPlayerId,
                        teamMemberId: linkedPlayer?.teamMemberId,
                        boardPositionLabel:
                          target.boardPositionLabel ?? linkedPlayer?.positionLabel,
                      });
                    }}
                  >
                    <option
                      value=""
                      className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                    >
                      Unlinked
                    </option>
                    {playerOptions.map((player) => (
                      <option
                        key={player.id}
                        value={player.id}
                        className="bg-[var(--panel-2)]"
                        style={{
                          color: linkedSquadPlayerIdsOnBoard.has(player.id)
                            ? "var(--ink-1)"
                            : "var(--ink-0)",
                        }}
                      >
                        {player.label}
                        {linkedSquadPlayerIdsOnBoard.has(player.id)
                          ? " [Linked]"
                          : ""}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Position on board</span>
                  <div className="flex items-center gap-2">
                    <input
                      className="h-8 w-full rounded-lg border border-[var(--line)] bg-transparent px-2 text-xs text-[var(--ink-0)]"
                      value={target.boardPositionLabel ?? ""}
                      placeholder={
                        target.squadPlayerId
                          ? squadPlayerById.get(target.squadPlayerId)?.positionLabel ||
                            "e.g. CM"
                          : "e.g. CM"
                      }
                      onChange={(event) =>
                        update({ boardPositionLabel: event.target.value })
                      }
                    />
                    <button
                      className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                      onClick={() =>
                        update({
                          boardPositionLabel:
                            target.squadPlayerId
                              ? squadPlayerById.get(target.squadPlayerId)?.positionLabel
                              : undefined,
                        })
                      }
                    >
                      Reset
                    </button>
                  </div>
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Vest color</span>
                  {target.squadPlayerId ? (
                    <div className="flex items-center gap-2">
                      <ColorPalettePicker
                        value={
                          squadPlayerById.get(target.squadPlayerId)?.vestColor ??
                          "#000000"
                        }
                        title="Vest color"
                        allowTransparent
                        onChange={(value) =>
                          (() => {
                            const squadPlayerId = target.squadPlayerId;
                            if (!squadPlayerId) {
                              return;
                            }
                            const squadId = squadIdByPlayerId.get(squadPlayerId);
                            if (!squadId) {
                              return;
                            }
                            updateSquadPlayer(squadId, squadPlayerId, {
                              vestColor: value,
                            });
                          })()
                        }
                      />
                      <button
                        className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                        onClick={() =>
                          (() => {
                            const squadPlayerId = target.squadPlayerId;
                            if (!squadPlayerId) {
                              return;
                            }
                            const squadId = squadIdByPlayerId.get(squadPlayerId);
                            if (!squadId) {
                              return;
                            }
                            updateSquadPlayer(squadId, squadPlayerId, {
                              vestColor: undefined,
                            });
                          })()
                        }
                      >
                        Clear
                      </button>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <ColorPalettePicker
                        value={target.vestColor ?? "#000000"}
                        title="Vest color"
                        allowTransparent
                        onChange={(value) => update({ vestColor: value })}
                      />
                      <button
                        className="rounded-full border border-[var(--line)] px-3 py-1 text-[11px] hover:border-[var(--accent-1)] hover:text-[var(--accent-1)]"
                        onClick={() => update({ vestColor: undefined })}
                      >
                        Clear
                      </button>
                    </div>
                  )}
                </label>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={Boolean(target.hasBall)}
                    onChange={(event) =>
                      update({ hasBall: event.target.checked })
                    }
                  />
                  Player has ball
                </label>
              </div>
            </div>
          )}

          {target.type === "ball" && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">Ball</p>
              <div className="mt-2 grid gap-2">
                <label className="space-y-1">
                  <span className="text-[11px]">Attach to player</span>
                  <select
                    className="h-8 w-full rounded-lg border border-[var(--line)] bg-[var(--panel-2)] px-2 text-xs text-[var(--ink-0)]"
                    value={target.attachedToId ?? ""}
                    onChange={(event) =>
                      update({
                        attachedToId: event.target.value || undefined,
                      })
                    }
                  >
                    <option
                      value=""
                      className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                    >
                      Free
                    </option>
                    {objects
                      .filter((item) => item.type === "player")
                      .map((item) => (
                        <option
                          key={item.id}
                          value={item.id}
                          className="bg-[var(--panel-2)] text-[var(--ink-0)]"
                        >
                          Player {item.id.slice(0, 4)}
                        </option>
                      ))}
                  </select>
                </label>
              </div>
            </div>
          )}

          {target.type === "text" && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">Text</p>
              <div className="mt-2 grid gap-2">
                <textarea
                  className="min-h-[80px] w-full rounded-lg border border-[var(--line)] bg-transparent p-2 text-xs text-[var(--ink-0)]"
                  value={target.text}
                  onChange={(event) => update({ text: event.target.value })}
                />
                <label className="space-y-1">
                  <span className="text-[11px]">Rotation</span>
                  {numberField(target.rotation, (value) =>
                    update({ rotation: value })
                  )}
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Font size</span>
                  {numberField(target.fontSize, (value) =>
                    update({ fontSize: value })
                  )}
                </label>
                <label className="space-y-1">
                  <span className="text-[11px]">Align</span>
                  <select
                    className="h-8 w-full rounded-lg border border-[var(--line)] bg-[var(--panel-2)] px-2 text-xs text-[var(--ink-0)]"
                    value={target.align}
                    onChange={(event) =>
                      update({ align: event.target.value as TextLabel["align"] })
                    }
                  >
                    <option value="left" className="bg-[var(--panel-2)] text-[var(--ink-0)]">
                      Left
                    </option>
                    <option value="center" className="bg-[var(--panel-2)] text-[var(--ink-0)]">
                      Center
                    </option>
                    <option value="right" className="bg-[var(--panel-2)] text-[var(--ink-0)]">
                      Right
                    </option>
                  </select>
                </label>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={target.bold}
                    onChange={(event) => update({ bold: event.target.checked })}
                  />
                  Bold
                </label>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={target.background}
                    onChange={(event) =>
                      update({ background: event.target.checked })
                    }
                  />
                  Background
                </label>
              </div>
            </div>
          )}

          {target.type === "arrow" && (
            <div className="rounded-2xl border border-[var(--line)] p-3">
              <p className="text-[11px] uppercase text-[var(--ink-1)]">Arrow</p>
              <div className="mt-2 grid gap-2">
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={target.head}
                    onChange={(event) => update({ head: event.target.checked })}
                  />
                  Arrow head
                </label>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={Boolean(target.curved)}
                    onChange={(event) => {
                      const nextCurved = event.target.checked;
                      if (!nextCurved) {
                        update({ curved: false, control: undefined });
                        return;
                      }
                      const end = { x: target.points[2], y: target.points[3] };
                      update({
                        curved: true,
                        control: { x: end.x / 2, y: end.y / 2 },
                      });
                    }}
                  />
                  Curved
                </label>
                <label className="flex items-center gap-2 text-[11px]">
                  <input
                    type="checkbox"
                    checked={target.dashed}
                    onChange={(event) => update({ dashed: event.target.checked })}
                  />
                  Dashed
                </label>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
