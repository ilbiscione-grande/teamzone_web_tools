import type { StateCreator } from "zustand";
import type { ProjectActions, ProjectStore } from "./types";
import type { DrawableObject, PlayerToken } from "@/models";
import { getPlayerTokenLinkKey } from "@/utils/board";

type ObjectActionSlice = Pick<
  ProjectActions,
  "setFrameObjects" | "addObject" | "updateObject" | "removeObject"
>;

export const createObjectActions: StateCreator<
  ProjectStore,
  [["zustand/immer", never]],
  [],
  ObjectActionSlice
> = (set, _get, _store) => ({
  setFrameObjects: (boardId, frameIndex, objects) => {
    set((state) => {
      if (state.project?.isShared) {
        return;
      }
      const board = state.project?.boards.find((item) => item.id === boardId);
      if (!board || !board.frames[frameIndex]) {
        return;
      }
      board.frames[frameIndex].objects = objects;
      if (board.mode === "STATIC") {
        board.layers = objects;
      }
      if (state.project) {
        state.project.updatedAt = new Date().toISOString();
      }
    });
  },
  addObject: (boardId, frameIndex, object: DrawableObject) => {
    set((state) => {
      if (state.project?.isShared) {
        return;
      }
      const board = state.project?.boards.find((item) => item.id === boardId);
      if (!board || !board.frames[frameIndex]) {
        return;
      }
      board.frames[frameIndex].objects.push(object);
      if (board.mode === "STATIC") {
        board.layers = board.frames[frameIndex].objects;
      }
      if (state.project) {
        state.project.updatedAt = new Date().toISOString();
      }
    });
  },
  updateObject: (boardId, frameIndex, objectId, payload) => {
    set((state) => {
      if (state.project?.isShared) {
        return;
      }
      const board = state.project?.boards.find((item) => item.id === boardId);
      const frame = board?.frames[frameIndex];
      if (!frame) {
        return;
      }
      const target = frame.objects.find((item) => item.id === objectId);
      if (!target) {
        return;
      }
      Object.assign(target, payload);
      if (
        target.type === "player" &&
        Object.prototype.hasOwnProperty.call(payload, "squadPlayerId") &&
        board
      ) {
        const nextSquadPlayerId = (payload as { squadPlayerId?: string })
          .squadPlayerId;
        const nextTeamMemberId = (payload as { teamMemberId?: string })
          .teamMemberId;
        const linkedSquadPlayerPosition = nextSquadPlayerId
          ? state.project?.squads
              .flatMap((squad) => squad.players)
              .find((player) => player.id === nextSquadPlayerId)?.positionLabel
          : undefined;
        if (
          nextSquadPlayerId &&
          !(target as PlayerToken).boardPositionLabel &&
          linkedSquadPlayerPosition
        ) {
          (target as PlayerToken).boardPositionLabel = linkedSquadPlayerPosition;
        }
        board.frames.forEach((entry) => {
          const match = entry.objects.find((item) => item.id === objectId);
          if (match && match.type === "player") {
            match.squadPlayerId = nextSquadPlayerId;
            match.teamMemberId = nextTeamMemberId;
            if (
              nextSquadPlayerId &&
              !(match as PlayerToken).boardPositionLabel &&
              linkedSquadPlayerPosition
            ) {
              (match as PlayerToken).boardPositionLabel =
                linkedSquadPlayerPosition;
            }
          }
          if (!nextSquadPlayerId) {
            return;
          }
          entry.objects.forEach((item) => {
            const nextLinkKey = nextTeamMemberId ?? nextSquadPlayerId;
            if (
              item.id !== objectId &&
              item.type === "player" &&
              nextLinkKey &&
              getPlayerTokenLinkKey(item) === nextLinkKey
            ) {
              item.squadPlayerId = undefined;
              item.teamMemberId = undefined;
            }
          });
        });
      }
      if (board.mode === "STATIC") {
        board.layers = frame.objects;
      }
      if (state.project) {
        state.project.updatedAt = new Date().toISOString();
      }
    });
  },
  removeObject: (boardId, frameIndex, objectId) => {
    set((state) => {
      if (state.project?.isShared) {
        return;
      }
      const board = state.project?.boards.find((item) => item.id === boardId);
      const frame = board?.frames[frameIndex];
      if (!frame) {
        return;
      }
      frame.objects = frame.objects.filter((item) => item.id !== objectId);
      if (board.mode === "STATIC") {
        board.layers = frame.objects;
      }
      if (state.project) {
        state.project.updatedAt = new Date().toISOString();
      }
    });
  },
});
