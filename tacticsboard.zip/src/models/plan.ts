export type Plan = "FREE" | "AUTH" | "PAID";
