export type Point = {
  x: number;
  y: number;
};

export type Style = {
  stroke: string;
  fill: string;
  strokeWidth: number;
  dash: number[];
  opacity: number;
  outlineStroke?: string;
  outlineWidth?: number;
  fxLightningStrength?: number;
  fxShimmerStrength?: number;
  fxShimmerProgress?: number;
  fxDrawProgress?: number;
};

export type DrawableAnimation =
  | "none"
  | "fadeIn"
  | "fadeOut"
  | "draw"
  | "pop"
  | "pulse"
  | "zoom"
  | "highlight"
  | "lightning"
  | "lightPulse"
  | "shimmer";

export type BaseDrawable = {
  id: string;
  name?: string;
  type:
    | "player"
    | "ball"
    | "cone"
    | "pole"
    | "mannequin"
    | "goal"
    | "circle"
    | "polygon"
    | "rect"
    | "triangle"
    | "arrow"
    | "text"
    | "path";
  position: Point;
  rotation: number;
  scale: Point;
  style: Style;
  zIndex: number;
  locked: boolean;
  visible: boolean;
  animation?: DrawableAnimation;
};

export type PlayerToken = BaseDrawable & {
  type: "player";
  squadPlayerId?: string;
  teamMemberId?: string;
  // Board-local position label for this token (independent of squad master data).
  boardPositionLabel?: string;
  hasBall?: boolean;
  showName: boolean;
  showPosition: boolean;
  showNumber: boolean;
  tokenSize: number;
  vestColor?: string;
  moveControl?: Point;
};

export type BallToken = BaseDrawable & {
  type: "ball";
  attachedToId?: string;
  offset?: Point;
};

export type ConeToken = BaseDrawable & {
  type: "cone";
  width: number;
  height: number;
};

export type MiniGoal = BaseDrawable & {
  type: "goal";
  width: number;
  height: number;
};

export type PoleToken = BaseDrawable & {
  type: "pole";
  width: number;
  height: number;
};

export type MannequinToken = BaseDrawable & {
  type: "mannequin";
  width: number;
  height: number;
};

export type ShapeCircle = BaseDrawable & {
  type: "circle";
  radius: number;
};

export type ShapeRect = BaseDrawable & {
  type: "rect";
  width: number;
  height: number;
  cornerRadius: number;
};

export type ShapePolygon = BaseDrawable & {
  type: "polygon";
  points: number[];
};

export type ShapeTriangle = BaseDrawable & {
  type: "triangle";
  width: number;
  height: number;
};

export type ArrowLine = BaseDrawable & {
  type: "arrow";
  points: number[];
  head: boolean;
  dashed: boolean;
  curved?: boolean;
  control?: Point;
};

export type TextLabel = BaseDrawable & {
  type: "text";
  text: string;
  fontSize: number;
  bold: boolean;
  background: boolean;
  align: "left" | "center" | "right";
  width: number;
  height?: number;
};

export type MovementPath = BaseDrawable & {
  type: "path";
  points: number[];
  linkedToId?: string;
};

export type DrawableObject =
  | PlayerToken
  | BallToken
  | ConeToken
  | PoleToken
  | MannequinToken
  | MiniGoal
  | ShapeCircle
  | ShapePolygon
  | ShapeRect
  | ShapeTriangle
  | ArrowLine
  | TextLabel
  | MovementPath;
