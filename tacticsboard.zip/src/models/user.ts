export type AuthUser = {
  id?: string;
  email: string;
  name: string;
  createdAt: string;
};
