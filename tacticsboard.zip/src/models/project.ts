import type { Board } from "./board";
import type { Squad } from "./squad";

export type Project = {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  schemaVersion: number;
  isSample?: boolean;
  isShared?: boolean;
  sharedMeta?: {
    shareId: string;
    ownerEmail: string;
    permission: "view" | "comment";
    projectName: string;
    boardId: string;
  };
  settings: {
    homeKit: {
      shirt: string;
      shorts: string;
      socks: string;
      vest?: string;
    };
    awayKit: {
      shirt: string;
      shorts: string;
      socks: string;
      vest?: string;
    };
    attachBallToPlayer: boolean;
  };
  boards: Board[];
  squads: Squad[];
  activeBoardId?: string;
};

export type ProjectSummary = {
  id: string;
  name: string;
  updatedAt: string;
};
