import { supabase } from "@/utils/supabaseClient";

export type AdminUserRow = {
  id: string;
  email: string | null;
  name: string | null;
  plan: string;
  betaUser: boolean;
  isAdmin: boolean;
  createdAt: string;
  updatedAt: string;
};

export type AdminClubOption = {
  id: string;
  name: string;
};

export type AdminTeamOption = {
  id: string;
  clubId: string;
  name: string;
};

export type AdminClubMembershipRow = {
  id: string;
  clubId: string;
  clubName: string;
  clubStatus: "active" | "archived";
  clubLogoUrl: string | null;
  kitShirt: string;
  kitShirtSecondary: string;
  kitShorts: string;
  kitSocks: string;
  kitVest: string | null;
  kitJerseyType: "solid" | "split" | "stripe" | "sash" | "pinstripe";
  clubRole: string;
  isClubAdmin: boolean;
};

export type AdminTeamMembershipRow = {
  id: string;
  teamId: string;
  clubId: string;
  teamName: string;
  teamStatus: "active" | "archived";
  teamLogoUrl: string | null;
  teamType: string;
  ageGroup: string | null;
  seasonLabel: string | null;
  kitShirt: string | null;
  kitShirtSecondary: string | null;
  kitShorts: string | null;
  kitSocks: string | null;
  kitVest: string | null;
  kitJerseyType: "solid" | "split" | "stripe" | "sash" | "pinstripe" | null;
  teamRole: string;
  teamPosition: string | null;
  isTeamAdmin: boolean;
};

export type AdminUserMemberships = {
  clubs: AdminClubOption[];
  teams: AdminTeamOption[];
  clubMemberships: AdminClubMembershipRow[];
  teamMemberships: AdminTeamMembershipRow[];
};

export type AdminReportRow = {
  id: string;
  created_at: string;
  report_type: string;
  user_email: string | null;
  project_name: string | null;
  board_name: string | null;
  body: string;
  source: "bug_report" | "public_board_report" | "public_project_report";
};

const getAccessToken = async () => {
  if (!supabase) {
    return null;
  }
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token ?? null;
};

const adminFetch = async (path: string, init?: RequestInit) => {
  const accessToken = await getAccessToken();
  if (!accessToken) {
    return { ok: false as const, error: "Not authenticated." };
  }
  const response = await fetch(path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${accessToken}`,
      ...(init?.headers ?? {}),
    },
  });
  const payload = (await response.json().catch(() => ({}))) as {
    error?: string;
    users?: AdminUserRow[];
    reports?: AdminReportRow[];
    networkCounters?: {
      key: string;
      calls: number;
      ok: number;
      error: number;
      errorRate: number;
    }[];
  };
  if (!response.ok) {
    return {
      ok: false as const,
      error: payload.error ?? "Request failed.",
    };
  }
  return { ok: true as const, payload };
};

export const fetchAdminUsers = async () => {
  const result = await adminFetch("/api/admin/users");
  if (!result.ok) {
    return result;
  }
  return { ok: true as const, users: result.payload.users ?? [] };
};

export const updateAdminUserFlags = async (payload: {
  id: string;
  betaUser?: boolean;
  isAdmin?: boolean;
}) => {
  const result = await adminFetch("/api/admin/users", {
    method: "PATCH",
    body: JSON.stringify(payload),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const fetchAdminReports = async () => {
  const result = await adminFetch("/api/admin/reports");
  if (!result.ok) {
    return result;
  }
  return { ok: true as const, reports: result.payload.reports ?? [] };
};

export type AdminAnalyticsSummary = {
  totalEvents: number;
  activeUsers30d: number;
  loginCount30d: number;
  averageSessionMinutes: number;
  totalHours30d: number;
};

export type AdminAnalyticsResponse = {
  summary: AdminAnalyticsSummary;
  toolUsage: { tool: string; count: number }[];
  loginMethods: { method: string; count: number }[];
  dailyActivity: { day: string; events: number; activeUsers: number }[];
  recentLogins: {
    at: string;
    userEmail: string | null;
    provider: string;
    path: string;
    device: string;
  }[];
  networkCounters: {
    key: string;
    calls: number;
    ok: number;
    error: number;
    errorRate: number;
  }[];
};

export const fetchAdminUserMemberships = async (userId: string) => {
  const result = await adminFetch(`/api/admin/memberships?userId=${encodeURIComponent(userId)}`);
  if (!result.ok) {
    return result;
  }
  const payload = result.payload as {
    memberships?: AdminUserMemberships;
  };
  return {
    ok: true as const,
    memberships: payload.memberships ?? {
      clubs: [],
      teams: [],
      clubMemberships: [],
      teamMemberships: [],
    },
  };
};

export const createAdminUserClubMembership = async (payload: {
  userId: string;
  clubId: string;
  clubRole: string;
  isClubAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "POST",
    body: JSON.stringify({
      kind: "club",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const updateAdminUserClubMembership = async (payload: {
  membershipId: string;
  clubRole: string;
  isClubAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "club",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const createAdminUserTeamMembership = async (payload: {
  userId: string;
  teamId: string;
  teamRole: string;
  teamPosition?: string | null;
  isTeamAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "POST",
    body: JSON.stringify({
      kind: "team",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const createAdminClub = async (payload: {
  userId: string;
  clubName: string;
  clubRole: string;
  isClubAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "POST",
    body: JSON.stringify({
      kind: "create_club",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const createAdminTeam = async (payload: {
  userId: string;
  clubId: string;
  teamName: string;
  teamType: string;
  ageGroup?: string | null;
  seasonLabel?: string | null;
  teamRole: string;
  teamPosition?: string | null;
  isTeamAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "POST",
    body: JSON.stringify({
      kind: "create_team",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const updateAdminUserTeamMembership = async (payload: {
  membershipId: string;
  teamRole: string;
  teamPosition?: string | null;
  isTeamAdmin: boolean;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "team",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const updateAdminClubDetails = async (payload: {
  clubId: string;
  clubName: string;
  clubLogoUrl?: string | null;
  kitShirt: string;
  kitShirtSecondary: string;
  kitShorts: string;
  kitSocks: string;
  kitVest?: string | null;
  kitJerseyType: "solid" | "split" | "stripe" | "sash" | "pinstripe";
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "club_details",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const updateAdminTeamDetails = async (payload: {
  teamId: string;
  teamName: string;
  teamLogoUrl?: string | null;
  teamType: string;
  ageGroup?: string | null;
  seasonLabel?: string | null;
  kitShirt?: string | null;
  kitShirtSecondary?: string | null;
  kitShorts?: string | null;
  kitSocks?: string | null;
  kitVest?: string | null;
  kitJerseyType?: "solid" | "split" | "stripe" | "sash" | "pinstripe" | null;
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "team_details",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const setAdminClubStatus = async (payload: {
  clubId: string;
  status: "active" | "archived";
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "club_status",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const setAdminTeamStatus = async (payload: {
  teamId: string;
  status: "active" | "archived";
}) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "PATCH",
    body: JSON.stringify({
      kind: "team_status",
      ...payload,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const deleteAdminClub = async (clubId: string) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "DELETE",
    body: JSON.stringify({
      kind: "club_delete",
      clubId,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const deleteAdminTeam = async (teamId: string) => {
  const result = await adminFetch("/api/admin/memberships", {
    method: "DELETE",
    body: JSON.stringify({
      kind: "team_delete",
      teamId,
    }),
  });
  if (!result.ok) {
    return result;
  }
  return { ok: true as const };
};

export const fetchAdminAnalytics = async () => {
  const result = await adminFetch("/api/admin/analytics");
  if (!result.ok) {
    return result;
  }
  const analytics = result.payload as Partial<AdminAnalyticsResponse>;
  return {
    ok: true as const,
    analytics: {
      summary: analytics.summary ?? {
        totalEvents: 0,
        activeUsers30d: 0,
        loginCount30d: 0,
        averageSessionMinutes: 0,
        totalHours30d: 0,
      },
      toolUsage: analytics.toolUsage ?? [],
      loginMethods: analytics.loginMethods ?? [],
      dailyActivity: analytics.dailyActivity ?? [],
      recentLogins: analytics.recentLogins ?? [],
      networkCounters: analytics.networkCounters ?? [],
    } satisfies AdminAnalyticsResponse,
  };
};
