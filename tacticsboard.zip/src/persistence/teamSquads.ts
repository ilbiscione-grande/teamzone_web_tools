import { supabase } from "@/utils/supabaseClient";
import type { Squad, SquadPlayer, SquadPreset } from "@/models";

type TeamRow = {
  id: string;
  owner_id: string;
  name: string;
  club_logo: string | null;
  kit_shirt: string | null;
  kit_shirt_secondary: string | null;
  kit_shorts: string | null;
  kit_socks: string | null;
  kit_vest: string | null;
  kit_jersey_type: string | null;
  created_at: string;
  updated_at: string;
};

type TeamSquadRow = {
  id: string;
  team_id: string;
  name: string;
  kit_data: Squad["kit"];
  captain_player_id: string | null;
  substitute_player_ids: string[] | null;
  created_at: string;
  updated_at: string;
};

type TeamPlayerRow = {
  id: string;
  team_id: string;
  name: string;
  position_label: string;
  is_active: boolean | null;
  number: number | null;
  vest_color: string | null;
  photo_url: string | null;
};

type TeamMemberRow = {
  id: string;
  team_id: string;
  user_id: string | null;
  display_name: string | null;
  team_role: string | null;
  team_position: string | null;
  is_team_admin: boolean | null;
  is_guest: boolean | null;
  is_active: boolean | null;
  shirt_number: number | null;
  photo_url: string | null;
  sort_order: number | null;
};

type TeamSquadPlayerRow = {
  id: string;
  squad_id: string;
  player_id: string;
  order_index: number;
  is_captain: boolean;
  is_substitute: boolean;
  source_team_id: string | null;
  source_player_id: string | null;
};

const TEAMS_TABLE = "teams";
const TEAM_MEMBERS_TABLE = "team_members";
const TEAM_SQUADS_TABLE = "team_squads";
const TEAM_PLAYERS_TABLE = "team_players";
const TEAM_SQUAD_PLAYERS_TABLE = "team_squad_players";
const UUID_PATTERN =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export const isUuid = (value: string | null | undefined): value is string =>
  typeof value === "string" && UUID_PATTERN.test(value);

export const toPersistedTeamPlayerId = (playerId: string) => {
  if (isUuid(playerId)) {
    return playerId;
  }
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  const randomChunk = () =>
    Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .slice(1);
  return `${randomChunk()}${randomChunk()}-${randomChunk()}-4${randomChunk().slice(
    0,
    3
  )}-${((8 + Math.random() * 4) | 0).toString(16)}${randomChunk().slice(
    0,
    3
  )}-${randomChunk()}${randomChunk()}${randomChunk()}`;
};

const getAuthUser = async () => {
  if (!supabase) {
    return null;
  }
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    return null;
  }
  return data.user;
};

const toSquadPlayer = (
  player: TeamPlayerRow,
  relation: TeamSquadPlayerRow,
  sourceTeamNameById: Map<string, string>
): SquadPlayer => ({
  id: player.id,
  teamMemberId: relation.source_player_id ?? undefined,
  name: player.name,
  positionLabel: player.position_label,
  active: player.is_active ?? true,
  number: player.number ?? undefined,
  vestColor: player.vest_color ?? undefined,
  photoUrl: player.photo_url ?? undefined,
  sourceTeamId: relation.source_team_id ?? undefined,
  sourceTeamName: relation.source_team_id
    ? sourceTeamNameById.get(relation.source_team_id)
    : undefined,
  sourcePlayerId: relation.source_player_id ?? undefined,
});

const toSquadPlayerFromMember = (
  member: TeamMemberRow,
  team: TeamRow,
  relation?: TeamSquadPlayerRow
): SquadPlayer => ({
  id: member.id,
  teamMemberId: member.id,
  name: member.display_name?.trim() || "Unnamed member",
  positionLabel: member.team_position?.trim() || "POS",
  active: member.is_active ?? true,
  number: member.shirt_number ?? undefined,
  photoUrl: member.photo_url ?? undefined,
  guest: member.is_guest ?? false,
  sourceTeamId: relation?.source_team_id ?? team.id,
  sourceTeamName: team.name,
  sourcePlayerId: member.id,
});

const fetchTeamsByIds = async (teamIds: string[]) => {
  if (!supabase || teamIds.length === 0) {
    return [] as TeamRow[];
  }
  const { data } = await supabase
    .from(TEAMS_TABLE)
    .select(
      "id, owner_id, name, club_logo, kit_shirt, kit_shirt_secondary, kit_shorts, kit_socks, kit_vest, kit_jersey_type, created_at, updated_at"
    )
    .in("id", teamIds);
  return (data ?? []) as TeamRow[];
};

const buildTeamsFromRows = async (
  teams: TeamRow[]
): Promise<SquadPreset[]> => {
  if (!supabase || teams.length === 0) {
    return [];
  }

  const teamIds = teams.map((team) => team.id);

  const [{ data: squadsData }, { data: teamMembersData }] = await Promise.all([
    supabase
      .from(TEAM_SQUADS_TABLE)
      .select(
        "id, team_id, name, kit_data, captain_player_id, substitute_player_ids, created_at, updated_at"
      )
      .in("team_id", teamIds),
    supabase
      .from(TEAM_MEMBERS_TABLE)
      .select(
        "id, team_id, user_id, display_name, team_role, team_position, is_team_admin, is_guest, is_active, shirt_number, photo_url, sort_order"
      )
      .in("team_id", teamIds),
  ]);

  const squads = (squadsData ?? []) as TeamSquadRow[];
  const teamMembers = (teamMembersData ?? []) as TeamMemberRow[];

  const squadIds = squads.map((squad) => squad.id);
  const { data: squadPlayersData } = await supabase
    .from(TEAM_SQUAD_PLAYERS_TABLE)
    .select(
      "id, squad_id, player_id, order_index, is_captain, is_substitute, source_team_id, source_player_id"
    )
    .in("squad_id", squadIds.length > 0 ? squadIds : ["00000000-0000-0000-0000-000000000000"]);

  const squadPlayers = (squadPlayersData ?? []) as TeamSquadPlayerRow[];

  const sourceTeamIds = Array.from(
    new Set(
      squadPlayers
        .map((entry) => entry.source_team_id)
        .filter((value): value is string => Boolean(value))
    )
  );

  const sourceTeams = await fetchTeamsByIds(sourceTeamIds);
  const sourceTeamNameById = new Map<string, string>();
  sourceTeams.forEach((team) => sourceTeamNameById.set(team.id, team.name));

  const squadByTeamId = new Map<string, TeamSquadRow>();
  squads.forEach((squad) => squadByTeamId.set(squad.team_id, squad));

  const membersByTeamId = new Map<string, TeamMemberRow[]>();
  teamMembers.forEach((member) => {
    const list = membersByTeamId.get(member.team_id) ?? [];
    list.push(member);
    membersByTeamId.set(member.team_id, list);
  });

  const legacyTeamIds = teamIds.filter((teamId) => {
    const members = membersByTeamId.get(teamId) ?? [];
    return !members.some(
      (member) => member.team_role === "player" || member.is_guest === true
    );
  });

  const { data: playersData } =
    legacyTeamIds.length > 0
      ? await supabase
          .from(TEAM_PLAYERS_TABLE)
          .select(
            "id, team_id, name, position_label, is_active, number, vest_color, photo_url"
          )
          .in("team_id", legacyTeamIds)
      : ({ data: [] as TeamPlayerRow[] } as const);
  const players = (playersData ?? []) as TeamPlayerRow[];
  const playersById = new Map<string, TeamPlayerRow>();
  players.forEach((player) => playersById.set(player.id, player));

  const squadPlayersBySquadId = new Map<string, TeamSquadPlayerRow[]>();
  squadPlayers.forEach((entry) => {
    const list = squadPlayersBySquadId.get(entry.squad_id) ?? [];
    list.push(entry);
    squadPlayersBySquadId.set(entry.squad_id, list);
  });

  return teams
    .slice()
    .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
    .map((team) => {
      const squad = squadByTeamId.get(team.id);
      const orderedRelations = squad
        ? (squadPlayersBySquadId.get(squad.id) ?? [])
            .slice()
            .sort((a, b) => a.order_index - b.order_index)
        : [];
      const orderedMembers = (membersByTeamId.get(team.id) ?? [])
        .filter((member) => member.team_role === "player" || member.is_guest === true)
        .slice()
        .sort(
          (a, b) =>
            (a.sort_order ?? 0) - (b.sort_order ?? 0) ||
            (a.display_name ?? "").localeCompare(b.display_name ?? "", "sv")
        );
      const relationsByMemberId = new Map<string, TeamSquadPlayerRow>();
      orderedRelations.forEach((relation) => {
        if (relation.source_player_id) {
          relationsByMemberId.set(relation.source_player_id, relation);
        }
      });

      const mappedPlayers =
        orderedMembers.length > 0
          ? orderedMembers.map((member) =>
              toSquadPlayerFromMember(
                member,
                team,
                relationsByMemberId.get(member.id)
              )
            )
          : orderedRelations
              .map((relation) => {
                const player = playersById.get(relation.player_id);
                if (!player) {
                  return null;
                }
                return toSquadPlayer(player, relation, sourceTeamNameById);
              })
              .filter((player): player is SquadPlayer => Boolean(player));

      const captainId =
        orderedMembers.length > 0
          ? orderedRelations.find((relation) => relation.is_captain)?.source_player_id ??
            undefined
          : squad?.captain_player_id ?? undefined;
      const substituteIds =
        orderedMembers.length > 0
          ? orderedRelations
              .filter((relation) => relation.is_substitute)
              .map((relation) => relation.source_player_id)
              .filter((id): id is string => Boolean(id))
          : squad?.substitute_player_ids?.filter((id): id is string => Boolean(id)) ??
            orderedRelations
              .filter((relation) => relation.is_substitute)
              .map((relation) => relation.player_id);

      const squadData: Squad = {
        id: squad?.id ?? team.id,
        name: squad?.name ?? team.name,
        clubLogo: team.club_logo ?? undefined,
        kit:
          squad?.kit_data ??
          ({
            shirt: team.kit_shirt ?? "#e4573f",
            shirtSecondary: team.kit_shirt_secondary ?? "#f3f3f3",
            shorts: team.kit_shorts ?? "#f3f3f3",
            socks: team.kit_socks ?? "#f3f3f3",
            vest: team.kit_vest ?? undefined,
            jerseyType:
              team.kit_jersey_type === "split" ||
              team.kit_jersey_type === "stripe" ||
              team.kit_jersey_type === "sash" ||
              team.kit_jersey_type === "pinstripe"
                ? team.kit_jersey_type
                : "solid",
          } as Squad["kit"]),
        players: mappedPlayers,
        captainId,
        substituteIds,
      };

      return {
        id: team.id,
        userId: team.owner_id,
        teamId: team.id,
        teamName: team.name,
        name: team.name,
        squad: squadData,
        createdAt: team.created_at,
        updatedAt: team.updated_at,
      } satisfies SquadPreset;
    });
};

const createOrReplaceTeamMembers = async (params: {
  teamId: string;
  players: SquadPlayer[];
}) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }

  const memberPayload = params.players.map((player, index) => {
    const memberId = isUuid(player.teamMemberId)
      ? player.teamMemberId
      : isUuid(player.sourcePlayerId)
        ? player.sourcePlayerId
        : isUuid(player.id)
          ? player.id
          : toPersistedTeamPlayerId(player.id);
    return {
      id: memberId,
      team_id: params.teamId,
      user_id: null,
      display_name: player.name,
      team_role: "player",
      team_position: player.positionLabel,
      is_team_admin: false,
      is_guest: player.guest ?? false,
      is_active: player.active ?? true,
      shirt_number: player.number ?? null,
      photo_url: player.photoUrl ?? null,
      sort_order: index,
      updated_at: new Date().toISOString(),
    };
  });

  if (memberPayload.length === 0) {
    return { ok: true as const, membersBySnapshotId: new Map<string, string>() };
  }

  const { data, error } = await supabase
    .from(TEAM_MEMBERS_TABLE)
    .upsert(memberPayload, { onConflict: "id" })
    .select(
      "id, team_id, user_id, display_name, team_role, team_position, is_team_admin, is_guest, is_active, shirt_number, photo_url, sort_order"
    );

  if (error) {
    return { ok: false as const, error: error.message };
  }

  const members = (data ?? []) as TeamMemberRow[];
  const memberIdsByRowId = new Map<string, string>();
  members.forEach((member) => memberIdsByRowId.set(member.id, member.id));
  const membersBySnapshotId = new Map<string, string>();
  params.players.forEach((player, index) => {
    const payload = memberPayload[index];
    membersBySnapshotId.set(
      player.id,
      memberIdsByRowId.get(payload?.id) ??
        payload?.id ??
        player.teamMemberId ??
        player.sourcePlayerId ??
        player.id
    );
  });

  return { ok: true as const, membersBySnapshotId };
};

const createOrReplaceTeamSquad = async (params: {
  teamId: string;
  squadName: string;
  kit: Squad["kit"];
  players: SquadPlayer[];
  captainId?: string;
  substituteIds?: string[];
}) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }

  const teamMembersResult = await createOrReplaceTeamMembers({
    teamId: params.teamId,
    players: params.players,
  });
  if (!teamMembersResult.ok) {
    return teamMembersResult;
  }
  const membersBySnapshotId = teamMembersResult.membersBySnapshotId;

  const upsertSquad = await supabase
    .from(TEAM_SQUADS_TABLE)
    .upsert(
      {
        team_id: params.teamId,
        name: params.squadName,
        kit_data: params.kit,
        captain_player_id: null,
        substitute_player_ids: [],
        updated_at: new Date().toISOString(),
      },
      { onConflict: "team_id" }
    )
    .select(
      "id, team_id, name, kit_data, captain_player_id, substitute_player_ids, created_at, updated_at"
    )
    .single();

  if (upsertSquad.error || !upsertSquad.data) {
    return {
      ok: false as const,
      error: upsertSquad.error?.message ?? "Could not save squad.",
    };
  }

  const squadId = (upsertSquad.data as TeamSquadRow).id;

  const { error: clearRelationsError } = await supabase
    .from(TEAM_SQUAD_PLAYERS_TABLE)
    .delete()
    .eq("squad_id", squadId);
  if (clearRelationsError) {
    return { ok: false as const, error: clearRelationsError.message };
  }

  const { data: existingPlayersData, error: existingPlayersError } = await supabase
    .from(TEAM_PLAYERS_TABLE)
    .select("id")
    .eq("team_id", params.teamId);
  if (existingPlayersError) {
    return { ok: false as const, error: existingPlayersError.message };
  }

  const upsertPlayersPayload = params.players.map((player) => ({
    id: toPersistedTeamPlayerId(player.id),
    team_id: params.teamId,
    name: player.name,
    position_label: player.positionLabel,
    is_active: player.active ?? true,
    number: player.number ?? null,
    vest_color: player.vestColor ?? null,
    photo_url: player.photoUrl ?? null,
    updated_at: new Date().toISOString(),
  }));

  const { data: insertedPlayers, error: insertPlayersError } =
    upsertPlayersPayload.length > 0
      ? await supabase
          .from(TEAM_PLAYERS_TABLE)
          .upsert(upsertPlayersPayload, { onConflict: "id" })
          .select(
            "id, team_id, name, position_label, is_active, number, vest_color, photo_url"
          )
      : ({ data: [] as TeamPlayerRow[], error: null } as const);

  if (insertPlayersError) {
    return { ok: false as const, error: insertPlayersError.message };
  }

  const keepIds = new Set(params.players.map((player) => player.id));
  const removedIds = ((existingPlayersData ?? []) as Array<{ id: string }>)
    .map((entry) => entry.id)
    .filter((id) => !keepIds.has(id));
  if (removedIds.length > 0) {
    const { error: deleteRemovedError } = await supabase
      .from(TEAM_PLAYERS_TABLE)
      .delete()
      .eq("team_id", params.teamId)
      .in("id", removedIds);
    if (deleteRemovedError) {
      return { ok: false as const, error: deleteRemovedError.message };
    }
  }

  const insertedById = new Map<string, TeamPlayerRow>();
  ((insertedPlayers ?? []) as TeamPlayerRow[]).forEach((player) => {
    insertedById.set(player.id, player);
  });
  const originalToInserted = new Map<string, TeamPlayerRow>();
  params.players.forEach((player, index) => {
    const persistedId = upsertPlayersPayload[index]?.id;
    if (!persistedId) {
      return;
    }
    const inserted = insertedById.get(persistedId);
    if (inserted) {
      originalToInserted.set(player.id, inserted);
    }
  });

  const captainTarget = params.captainId
    ? originalToInserted.get(params.captainId)?.id
    : undefined;
  const substituteTargets = (params.substituteIds ?? [])
    .map((id) => originalToInserted.get(id)?.id)
    .filter((id): id is string => Boolean(id));

  const relationPayload = params.players
    .map((player, orderIndex) => {
      const inserted = originalToInserted.get(player.id);
      if (!inserted) {
        return null;
      }
      return {
        squad_id: squadId,
        player_id: inserted.id,
        order_index: orderIndex,
        is_captain: captainTarget ? captainTarget === inserted.id : false,
        is_substitute: substituteTargets.includes(inserted.id),
        source_team_id: isUuid(player.sourceTeamId) ? player.sourceTeamId : null,
        source_player_id: isUuid(
          membersBySnapshotId.get(player.id) ??
            player.teamMemberId ??
            player.sourcePlayerId
        )
          ? (membersBySnapshotId.get(player.id) ??
            player.teamMemberId ??
            player.sourcePlayerId)
          : null,
        updated_at: new Date().toISOString(),
      };
    })
    .filter((item) => item !== null);

  if (relationPayload.length > 0) {
    const { error: relationError } = await supabase
      .from(TEAM_SQUAD_PLAYERS_TABLE)
      .insert(relationPayload);
    if (relationError) {
      return { ok: false as const, error: relationError.message };
    }
  }

  const { error: updateCaptainError } = await supabase
    .from(TEAM_SQUADS_TABLE)
    .update({
      captain_player_id: captainTarget ?? null,
      substitute_player_ids: substituteTargets,
      updated_at: new Date().toISOString(),
    })
    .eq("id", squadId);

  if (updateCaptainError) {
    return { ok: false as const, error: updateCaptainError.message };
  }

  return { ok: true as const };
};

export const fetchTeamsWithSquad = async () => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }
  const user = await getAuthUser();
  if (!user) {
    return { ok: false as const, error: "Not authenticated." };
  }

  const { data: teamRows, error: teamError } = await supabase
    .from(TEAMS_TABLE)
    .select(
      "id, owner_id, name, club_logo, kit_shirt, kit_shirt_secondary, kit_shorts, kit_socks, kit_vest, kit_jersey_type, created_at, updated_at"
    )
    .eq("owner_id", user.id)
    .order("updated_at", { ascending: false });

  if (!teamError && (teamRows ?? []).length > 0) {
    const teams = await buildTeamsFromRows((teamRows ?? []) as TeamRow[]);
    return { ok: true as const, teams };
  }

  if (teamError) {
    return { ok: false as const, error: teamError.message };
  }

  return { ok: true as const, teams: [] as SquadPreset[] };
};

export const createTeamWithSquad = async (payload: {
  name: string;
  squad: Squad;
}) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }
  const user = await getAuthUser();
  if (!user) {
    return { ok: false as const, error: "Not authenticated." };
  }

  const now = new Date().toISOString();
  const { data: team, error: teamError } = await supabase
    .from(TEAMS_TABLE)
    .insert({
      owner_id: user.id,
      name: payload.name,
      club_logo: payload.squad.clubLogo ?? null,
      kit_shirt: payload.squad.kit.shirt,
      kit_shirt_secondary:
        payload.squad.kit.shirtSecondary ?? payload.squad.kit.shirt,
      kit_shorts: payload.squad.kit.shorts,
      kit_socks: payload.squad.kit.socks,
      kit_vest: payload.squad.kit.vest ?? null,
      kit_jersey_type: payload.squad.kit.jerseyType ?? "solid",
      updated_at: now,
    })
    .select(
      "id, owner_id, name, club_logo, kit_shirt, kit_shirt_secondary, kit_shorts, kit_socks, kit_vest, kit_jersey_type, created_at, updated_at"
    )
    .single();

  if (teamError || !team) {
    return { ok: false as const, error: teamError?.message ?? "Could not create team." };
  }

  await supabase
    .from(TEAM_MEMBERS_TABLE)
    .upsert(
      {
        team_id: team.id,
        user_id: user.id,
        role: "owner",
        team_role: "leader",
        team_position: "head_coach",
        is_team_admin: true,
      },
      { onConflict: "team_id,user_id" }
    );

  const saveSquad = await createOrReplaceTeamSquad({
    teamId: team.id,
    squadName: payload.squad.name || payload.name,
    kit: payload.squad.kit,
    players: payload.squad.players,
    captainId: payload.squad.captainId,
    substituteIds: payload.squad.substituteIds,
  });

  if (!saveSquad.ok) {
    return saveSquad;
  }

  const teams = await buildTeamsFromRows([team as TeamRow]);
  if (teams.length === 0) {
    return { ok: false as const, error: "Could not fetch saved team." };
  }

  return { ok: true as const, team: teams[0] };
};

export const updateTeamWithSquad = async (payload: {
  id: string;
  name?: string;
  squad?: Squad;
}) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }
  const user = await getAuthUser();
  if (!user) {
    return { ok: false as const, error: "Not authenticated." };
  }

  const { data: team, error: teamError } = await supabase
    .from(TEAMS_TABLE)
    .select(
      "id, owner_id, name, club_logo, kit_shirt, kit_shirt_secondary, kit_shorts, kit_socks, kit_vest, kit_jersey_type, created_at, updated_at"
    )
    .eq("id", payload.id)
    .eq("owner_id", user.id)
    .maybeSingle();

  if (teamError) {
    return { ok: false as const, error: teamError.message };
  }
  if (!team) {
    return { ok: false as const, error: "Team not found." };
  }

  const teamUpdate: Record<string, unknown> = {
    updated_at: new Date().toISOString(),
  };
  if (payload.name) {
    teamUpdate.name = payload.name;
  }
  if (payload.squad?.clubLogo !== undefined) {
    teamUpdate.club_logo = payload.squad.clubLogo ?? null;
  }
  if (payload.squad) {
    teamUpdate.kit_shirt = payload.squad.kit.shirt;
    teamUpdate.kit_shirt_secondary =
      payload.squad.kit.shirtSecondary ?? payload.squad.kit.shirt;
    teamUpdate.kit_shorts = payload.squad.kit.shorts;
    teamUpdate.kit_socks = payload.squad.kit.socks;
    teamUpdate.kit_vest = payload.squad.kit.vest ?? null;
    teamUpdate.kit_jersey_type = payload.squad.kit.jerseyType ?? "solid";
  }

  const { error: teamUpdateError } = await supabase
    .from(TEAMS_TABLE)
    .update(teamUpdate)
    .eq("id", team.id)
    .eq("owner_id", user.id);

  if (teamUpdateError) {
    return { ok: false as const, error: teamUpdateError.message };
  }

  if (payload.squad) {
    const saveSquad = await createOrReplaceTeamSquad({
      teamId: team.id,
      squadName: payload.squad.name || payload.name || team.name,
      kit: payload.squad.kit,
      players: payload.squad.players,
      captainId: payload.squad.captainId,
      substituteIds: payload.squad.substituteIds,
    });
    if (!saveSquad.ok) {
      return saveSquad;
    }
  }

  const updatedTeams = await fetchTeamsByIds([team.id]);
  const teams = await buildTeamsFromRows(updatedTeams);
  const teamWithSquad = teams[0];
  if (!teamWithSquad) {
    return { ok: false as const, error: "Could not fetch updated team." };
  }

  return { ok: true as const, team: teamWithSquad };
};

export const deleteTeam = async (teamId: string) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }
  const user = await getAuthUser();
  if (!user) {
    return { ok: false as const, error: "Not authenticated." };
  }

  const { error } = await supabase
    .from(TEAMS_TABLE)
    .delete()
    .eq("id", teamId)
    .eq("owner_id", user.id);

  if (error) {
    return { ok: false as const, error: error.message };
  }

  return { ok: true as const };
};

export const listTeamPlayerCandidates = async (targetTeamId: string) => {
  if (!supabase) {
    return { ok: false as const, error: "Supabase not configured." };
  }
  const user = await getAuthUser();
  if (!user) {
    return { ok: false as const, error: "Not authenticated." };
  }

  const { data: teamsData, error: teamsError } = await supabase
    .from(TEAMS_TABLE)
    .select("id, name")
    .eq("owner_id", user.id)
    .neq("id", targetTeamId);

  if (teamsError) {
    return { ok: false as const, error: teamsError.message };
  }

  const sourceTeams = (teamsData ?? []) as Array<{ id: string; name: string }>;
  if (sourceTeams.length === 0) {
    return { ok: true as const, players: [] as Array<SquadPlayer & { teamId: string; teamName: string }> };
  }

  const { data: membersData, error: membersError } = await supabase
    .from(TEAM_MEMBERS_TABLE)
    .select(
      "id, team_id, user_id, display_name, team_role, team_position, is_team_admin, is_guest, is_active, shirt_number, photo_url, sort_order"
    )
    .in(
      "team_id",
      sourceTeams.map((team) => team.id)
    );

  if (membersError) {
    return { ok: false as const, error: membersError.message };
  }

  const teamNameById = new Map(sourceTeams.map((team) => [team.id, team.name]));
  const players = ((membersData ?? []) as TeamMemberRow[])
    .filter((member) => member.team_role === "player" || member.is_guest === true)
    .sort(
      (a, b) =>
        (a.sort_order ?? 0) - (b.sort_order ?? 0) ||
        (a.display_name ?? "").localeCompare(b.display_name ?? "", "sv")
    )
    .map((member) => ({
      id: member.id,
      teamId: member.team_id,
      teamName: teamNameById.get(member.team_id) ?? "Other team",
      name: member.display_name?.trim() || "Unnamed member",
      positionLabel: member.team_position?.trim() || "POS",
      active: member.is_active ?? true,
      number: member.shirt_number ?? undefined,
      photoUrl: member.photo_url ?? undefined,
      guest: member.is_guest ?? false,
      sourceTeamId: member.team_id,
      teamMemberId: member.id,
      sourcePlayerId: member.id,
    }));

  return { ok: true as const, players };
};
