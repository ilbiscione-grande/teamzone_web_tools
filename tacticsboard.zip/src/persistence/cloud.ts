import type { Board, Project, ProjectSummary } from "@/models";
import { supabase } from "@/utils/supabaseClient";
import {
  loadProject,
  loadProjectIndex,
  saveProject,
  saveProjectIndex,
} from "@/persistence/storage";
import { recordNetworkCall } from "@/persistence/networkCounters";

const TABLE = "projects";
const BOARDS_TABLE = "project_boards";
const SESSION_KEY_STORAGE = "tacticsboard:sessionKey";
const SESSION_NONCE_STORAGE = "tacticsboard:sessionNonce";
const SESSION_DEVICE_ID_STORAGE = "tacticsboard:deviceId";
const saveQueueByProject = new Map<string, Promise<boolean>>();
const pendingByProject = new Map<string, Project>();
const lastCloudSavedUpdatedAtByProject = new Map<string, string>();
type BoardSyncSnapshot = {
  signature: string;
  orderIndex: number;
};
const boardCacheByProject = new Map<string, Map<string, BoardSyncSnapshot>>();
const sessionTouchByUser = new Map<string, number>();

const safeSetLocalStorageItem = (key: string, value: string) => {
  if (typeof window === "undefined") {
    return;
  }
  try {
    window.localStorage.setItem(key, value);
  } catch (error) {
    console.warn(`Could not persist local storage key "${key}".`, error);
  }
};

const getUserId = async () => {
  if (!supabase) {
    return null;
  }
  const { data } = await supabase.auth.getUser();
  return data.user?.id ?? null;
};

const toSummary = (row: {
  id: string;
  name: string;
  updated_at: string | null;
  created_at: string | null;
}): ProjectSummary => ({
  id: row.id,
  name: row.name,
  updatedAt: row.updated_at ?? row.created_at ?? new Date().toISOString(),
});

const boardSignature = (board: Board) => JSON.stringify(board);

const getCurrentSessionKey = async (userId: string) => {
  if (typeof window !== "undefined") {
    const cached = window.localStorage.getItem(SESSION_KEY_STORAGE);
    if (cached && cached.startsWith(`${userId}:`)) {
      return cached;
    }
  }
  const existingDeviceId =
    typeof window !== "undefined"
      ? window.localStorage.getItem(SESSION_DEVICE_ID_STORAGE)
      : null;
  const deviceId =
    existingDeviceId && existingDeviceId.length > 0
      ? existingDeviceId
      : (typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const existingNonce =
    typeof window !== "undefined"
      ? window.localStorage.getItem(SESSION_NONCE_STORAGE)
      : null;
  const nonce =
    existingNonce && existingNonce.length > 0
      ? existingNonce
      : (typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const sessionKey = `${userId}:${deviceId}:${nonce}`;
  if (typeof window !== "undefined") {
    safeSetLocalStorageItem(SESSION_DEVICE_ID_STORAGE, deviceId);
    safeSetLocalStorageItem(SESSION_NONCE_STORAGE, nonce);
    safeSetLocalStorageItem(SESSION_KEY_STORAGE, sessionKey);
  }
  return sessionKey;
};

export const touchSessionActivityCloud = async (): Promise<void> => {
  if (!supabase) {
    return;
  }
  const userId = await getUserId();
  if (!userId) {
    return;
  }
  const now = Date.now();
  const lastTouch = sessionTouchByUser.get(userId) ?? 0;
  if (now - lastTouch < 60_000) {
    return;
  }
  if (typeof window !== "undefined" && !window.navigator.onLine) {
    return;
  }
  const sessionKey = await getCurrentSessionKey(userId);
  if (!sessionKey) {
    return;
  }
  const { data: existing, error: existingError } = await supabase
    .from("user_sessions")
    .select("session_key")
    .eq("user_id", userId)
    .maybeSingle();
  recordNetworkCall("supabase.user_sessions.get", !existingError);
  // Never steal session ownership from a newer login on another device.
  if (existing?.session_key && existing.session_key !== sessionKey) {
    return;
  }
  sessionTouchByUser.set(userId, now);
  const { error: touchError } = await supabase.from("user_sessions").upsert(
    {
      user_id: userId,
      session_key: sessionKey,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id" }
  );
  recordNetworkCall("supabase.user_sessions.upsert", !touchError);
};

export const fetchProjectIndexCloud = async (): Promise<ProjectSummary[]> => {
  if (!supabase) {
    return [];
  }
  const userId = await getUserId();
  if (!userId) {
    return [];
  }
  const { data, error } = await supabase
    .from(TABLE)
    .select("id,name,updated_at,created_at")
    .eq("user_id", userId)
    .order("updated_at", { ascending: false });
  recordNetworkCall("supabase.projects.index", !error);
  if (error || !data) {
    return [];
  }
  return data.map(toSummary);
};

export const fetchProjectCloud = async (id: string): Promise<Project | null> => {
  if (!supabase) {
    return null;
  }
  const userId = await getUserId();
  if (!userId) {
    return null;
  }
  const { data, error } = await supabase
    .from(TABLE)
    .select("id,name,created_at,updated_at,data")
    .eq("id", id)
    .eq("user_id", userId)
    .single();
  recordNetworkCall("supabase.projects.get", !error);
  if (error || !data) {
    return null;
  }
  const base = data.data as Project;

  const { data: boardRows, error: boardsError } = await supabase
    .from(BOARDS_TABLE)
    .select("id,board_name,order_index,updated_at,board_data")
    .eq("project_id", id)
    .eq("user_id", userId)
    .order("order_index", { ascending: true });
  recordNetworkCall("supabase.project_boards.list", !boardsError);

  // Backward compatibility: if board rows are missing, keep boards from legacy project payload.
  if (boardsError || !boardRows || boardRows.length === 0) {
    return base;
  }

  const boards = boardRows.map((row) => {
    const parsed = row.board_data as Board;
    return {
      ...parsed,
      id: parsed.id || row.id,
      name: parsed.name || row.board_name,
    };
  });

  const cached = new Map<string, BoardSyncSnapshot>();
  boards.forEach((board, index) => {
    cached.set(board.id, { signature: boardSignature(board), orderIndex: index });
  });
  boardCacheByProject.set(id, cached);

  return {
    ...base,
    boards,
  };
};

const saveProjectCloudNow = async (project: Project): Promise<boolean> => {
  const lastSavedUpdatedAt = lastCloudSavedUpdatedAtByProject.get(project.id);
  if (lastSavedUpdatedAt && lastSavedUpdatedAt === project.updatedAt) {
    return true;
  }
  if (!supabase) {
    return false;
  }
  const userId = await getUserId();
  if (!userId) {
    return false;
  }
  const projectPayload = {
    ...project,
    // Boards are stored in the dedicated table to keep project rows small.
    boards: [],
  };

  const payload = {
    id: project.id,
    user_id: userId,
    name: project.name,
    created_at: project.createdAt,
    updated_at: project.updatedAt,
    data: projectPayload,
  };
  const { error } = await supabase.from(TABLE).upsert(payload, {
    onConflict: "id",
  });
  recordNetworkCall("supabase.projects.upsert", !error);
  if (error) {
    return false;
  }

  const previous = boardCacheByProject.get(project.id) ?? new Map();
  const next = new Map<string, BoardSyncSnapshot>();

  const changedPayloads = project.boards
    .map((board, index) => {
      const signature = boardSignature(board);
      const snapshot: BoardSyncSnapshot = { signature, orderIndex: index };
      next.set(board.id, snapshot);
      const prev = previous.get(board.id);
      if (
        prev &&
        prev.signature === snapshot.signature &&
        prev.orderIndex === snapshot.orderIndex
      ) {
        return null;
      }
      return {
        id: board.id,
        project_id: project.id,
        user_id: userId,
        board_name: board.name,
        order_index: index,
        updated_at: project.updatedAt,
        board_data: board,
      };
    })
    .filter((item) => item !== null);

  if (changedPayloads.length > 0) {
    const { error: upsertBoardsError } = await supabase
      .from(BOARDS_TABLE)
      .upsert(changedPayloads, { onConflict: "id" });
    recordNetworkCall("supabase.project_boards.upsert", !upsertBoardsError);
    if (upsertBoardsError) {
      return false;
    }
  }

  const removedIds = Array.from(previous.keys()).filter((id) => !next.has(id));
  if (removedIds.length > 0) {
    const { error: removeBoardsError } = await supabase
      .from(BOARDS_TABLE)
      .delete()
      .eq("project_id", project.id)
      .eq("user_id", userId)
      .in("id", removedIds);
    recordNetworkCall("supabase.project_boards.delete", !removeBoardsError);
    if (removeBoardsError) {
      return false;
    }
  }

  boardCacheByProject.set(project.id, next);
  lastCloudSavedUpdatedAtByProject.set(project.id, project.updatedAt);

  return true;
};

export const saveProjectCloud = async (project: Project): Promise<boolean> => {
  pendingByProject.set(project.id, project);
  const existing = saveQueueByProject.get(project.id);
  if (existing) {
    return existing;
  }

  const run = (async () => {
    let ok = true;
    try {
      while (true) {
        const next = pendingByProject.get(project.id);
        if (!next) {
          break;
        }
        pendingByProject.delete(project.id);
        const stepOk = await saveProjectCloudNow(next);
        ok = ok && stepOk;
      }
      return ok;
    } finally {
      saveQueueByProject.delete(project.id);
    }
  })();

  saveQueueByProject.set(project.id, run);
  return run;
};

export const deleteProjectCloud = async (id: string): Promise<boolean> => {
  if (!supabase) {
    return false;
  }
  const userId = await getUserId();
  if (!userId) {
    return false;
  }
  const { error } = await supabase
    .from(TABLE)
    .delete()
    .eq("id", id)
    .eq("user_id", userId);
  recordNetworkCall("supabase.projects.delete", !error);
  if (error) {
    return false;
  }
  const { error: boardsError } = await supabase
    .from(BOARDS_TABLE)
    .delete()
    .eq("project_id", id)
    .eq("user_id", userId);
  recordNetworkCall("supabase.project_boards.delete", !boardsError);
  boardCacheByProject.delete(id);
  lastCloudSavedUpdatedAtByProject.delete(id);
  return !boardsError;
};

const compareUpdatedAt = (a: string, b: string) => a.localeCompare(b);

const safeTimestamp = (value: string | null | undefined) => {
  const ts = Date.parse(value ?? "");
  return Number.isFinite(ts) ? ts : -1;
};

const getProjectShapeScore = (project: Project) => {
  let frames = 0;
  let objects = 0;
  for (const board of project.boards ?? []) {
    frames += board.frames?.length ?? 0;
    for (const frame of board.frames ?? []) {
      objects += frame.objects?.length ?? 0;
    }
  }
  return {
    boards: project.boards?.length ?? 0,
    frames,
    objects,
  };
};

const chooseBestProject = (local: Project | null, cloud: Project | null) => {
  if (local && !cloud) {
    return local;
  }
  if (cloud && !local) {
    return cloud;
  }
  if (!local && !cloud) {
    return null;
  }
  const localProject = local as Project;
  const cloudProject = cloud as Project;

  const localTs = safeTimestamp(localProject.updatedAt ?? localProject.createdAt);
  const cloudTs = safeTimestamp(cloudProject.updatedAt ?? cloudProject.createdAt);

  if (localTs > cloudTs) {
    return localProject;
  }
  if (cloudTs > localTs) {
    return cloudProject;
  }

  const localShape = getProjectShapeScore(localProject);
  const cloudShape = getProjectShapeScore(cloudProject);

  if (localShape.boards !== cloudShape.boards) {
    return localShape.boards > cloudShape.boards ? localProject : cloudProject;
  }
  if (localShape.frames !== cloudShape.frames) {
    return localShape.frames > cloudShape.frames ? localProject : cloudProject;
  }
  if (localShape.objects !== cloudShape.objects) {
    return localShape.objects > cloudShape.objects ? localProject : cloudProject;
  }

  return localProject;
};

const sameProjectShape = (a: Project, b: Project) => {
  const aShape = getProjectShapeScore(a);
  const bShape = getProjectShapeScore(b);
  return (
    (a.updatedAt ?? "") === (b.updatedAt ?? "") &&
    aShape.boards === bShape.boards &&
    aShape.frames === bShape.frames &&
    aShape.objects === bShape.objects
  );
};

export const syncProjects = async (): Promise<ProjectSummary[]> => {
  if (!supabase) {
    return loadProjectIndex();
  }
  const userId = await getUserId();
  if (!userId) {
    return loadProjectIndex();
  }

  const localIndex = loadProjectIndex(userId);
  const cloudIndex = await fetchProjectIndexCloud();
  const localSummaryById = new Map(localIndex.map((item) => [item.id, item]));
  const cloudSummaryById = new Map(cloudIndex.map((item) => [item.id, item]));
  const localIdSet = new Set(localIndex.map((item) => item.id));
  const cloudIdSet = new Set(cloudIndex.map((item) => item.id));
  const allIds = new Set<string>([...localIdSet, ...cloudIdSet]);

  const summaries: ProjectSummary[] = [];

  for (const id of allIds) {
    const localProject = loadProject(id, userId);
    const localSummary = localSummaryById.get(id) ?? null;
    const cloudSummary = cloudSummaryById.get(id) ?? null;
    let cloudProject: Project | null = null;
    let best: Project | null = null;

    if (localProject && !cloudSummary) {
      best = localProject;
    } else if (!localProject && cloudSummary) {
      cloudProject = await fetchProjectCloud(id);
      best = cloudProject;
    } else if (localProject && cloudSummary) {
      const localAt = localProject.updatedAt ?? localProject.createdAt ?? "";
      const cloudAt = cloudSummary.updatedAt ?? "";
      if (localAt === cloudAt) {
        best = localProject;
      } else if (compareUpdatedAt(localAt, cloudAt) > 0) {
        best = localProject;
      } else {
        cloudProject = await fetchProjectCloud(id);
        best = chooseBestProject(localProject, cloudProject);
      }
    } else {
      best = null;
    }

    if (!best) {
      continue;
    }

    if (!localProject || !sameProjectShape(localProject, best)) {
      saveProject(best, userId);
    }
    if (!cloudProject || !sameProjectShape(cloudProject, best)) {
      await saveProjectCloud(best);
    }

    summaries.push({
      id: best.id,
      name: best.name,
      updatedAt: best.updatedAt ?? best.createdAt ?? new Date().toISOString(),
    });
  }

  const mergedIndex = summaries.sort((a, b) =>
    compareUpdatedAt(b.updatedAt, a.updatedAt)
  );
  saveProjectIndex(mergedIndex, userId);
  return mergedIndex;
};
