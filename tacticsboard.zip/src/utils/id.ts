import { nanoid } from "nanoid";

export const createId = () => nanoid();
